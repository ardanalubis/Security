// === IMPORT & CONFIG ===
const fs = require("fs");
const axios = require("axios");
const chalk = require("chalk");
const TelegramBot = require("node-telegram-bot-api");
const { 
    BOT_TOKEN, 
    GITHUB_REPO,
    GITHUB_FILE_PATH,
    GITHUB_PAT    
} = require("./config");
const ADMIN_FILE = "admin.json";
const RESELLER_FILE = "reseller.json";
const GITHUB_RAW_URL = `https://github.com/ardanalubis/Security/tree/main/token.json`;
const GITHUB_API_URL = `https://api.github.com/repos/${GITHUB_REPO}/contents/${GITHUB_FILE_PATH}`;

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

// === FILE HANDLING ===
function loadAdmins() {
  if (!fs.existsSync(ADMIN_FILE)) return { owners: [], admins: [] };
  return JSON.parse(fs.readFileSync(ADMIN_FILE));
}

function loadResellers() {
  if (!fs.existsSync(RESELLER_FILE)) return { resellers: [] };
  return JSON.parse(fs.readFileSync(RESELLER_FILE));
}

function saveAdmins(data) {
  fs.writeFileSync(ADMIN_FILE, JSON.stringify(data, null, 2));
}

function saveResellers(data) {
  fs.writeFileSync(RESELLER_FILE, JSON.stringify(data, null, 2));
}

// === ACCESS CONTROL ===
function isOwner(userId) {
  return loadAdmins().owners.includes(userId);
}

function isAdmin(userId) {
  const { admins, owners } = loadAdmins();
  return admins.includes(userId) || owners.includes(userId);
}

function isReseller(userId) {
  return loadResellers().resellers.includes(userId);
}

function hasAccess(userId) {
  return isOwner(userId) || isAdmin(userId) || isReseller(userId);
}
function badge(userId) {
  return {
    reseller: isReseller(userId) ? "Reseller ✅" : "",
    admin: isAdmin(userId) ? "Admin ✅" : "",
    owner: isOwner(userId) ? "Owner ✅" : ""
  };
}
function getUserStatus(userId) {
  const { reseller, admin, owner } = badge(userId);

  if (owner) return owner;
  if (admin) return admin;
  if (reseller) return reseller;
  return "No Access ❌";
}
// === GITHUB TOKEN HANDLING ===
async function fetchTokens() {
  try {
    const res = await axios.get(GITHUB_RAW_URL, { headers: { "Cache-Control": "no-cache" } });
    return res.data?.tokens || [];
  } catch (err) {
    return [];
  }
}

async function updateTokens(newTokens) {
  try {
    const { data } = await axios.get(GITHUB_API_URL, {
      headers: { Authorization: `token ${GITHUB_PAT}` },
    });
    const updatedContent = Buffer.from(JSON.stringify({ tokens: newTokens }, null, 2)).toString("base64");

    await axios.put(
      GITHUB_API_URL,
      { message: "Update token list", content: updatedContent, sha: data.sha },
      { headers: { Authorization: `token ${GITHUB_PAT}` } }
    );
    return true;
  } catch (err) {
    return false;
  }
}

const MENU_IMAGE = "https://files.catbox.moe/ofrv6p.jpg";

// ---------- MENU UTAMA ----------
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!hasAccess(userId)) return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");

  const menuText = "```\n𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘 KBN VIP 𝘾𝙍𝘼𝙎𝙃𝙀𝙍\n\n" +
                   "╭━⭓( 𝗕𝗢𝗧 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 )\n" +
                   "┃▢ Developer : @cskbnstore\n" +
                   "┃▢ NameBot : KBN VIP 𝘾𝙍𝘼𝙎𝙃𝙀𝙍\n" +
                   "╰━━━━━━━━━━━━━━━━━━⭓\n\n" +    
                   "╭━⭓( 𝗔𝗗𝗗 𝗧𝗢𝗞𝗘𝗡 )\n" +
                   "┃▢ /addtoken  <TOKEN>\n" +
                   "┃▢ /deltoken  <TOKEN>\n" +
                   "╰━━━━━━━━━━━━━━━━━━⭓\n\n" +        
                   "╭━⭓( 𝗢𝗪𝗡𝗘𝗥 𝗔𝗖𝗖𝗘𝗦𝗦 )\n" +
                   "┃▢ /addreseller <ID> \n" +
                   "┃▢ /delreseller <ID> \n" +
                   "┃▢ /listreseller \n" +
                   "┃▢ /addpt <ID> \n" +
                   "┃▢ /delpt <ID>\n" +
                   "┃▢ /listpt \n" +
                   "╰━━━━━━━━━━━━━━━━━━⭓```";

  bot.sendPhoto(chatId, MENU_IMAGE, { caption: menuText, parse_mode: "MarkdownV2" });
});

// ---------- TOKEN COMMANDS ----------
// Tambah Admin
bot.onText(/\/addpt(?:\s+(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newAdminId = parseInt(match[1]);

  if (!isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner yang bisa menambah admin!");
  if (!match[1]) return bot.sendMessage(chatId, "❗ Format salah!\n\nGunakan:\n`/addpt <USER_ID>`", { parse_mode: "Markdown" });
  if (isNaN(newAdminId)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const adminData = loadAdmins();
  if (adminData.admins.includes(newAdminId)) return bot.sendMessage(chatId, "⚠️ Admin sudah ada!");

  adminData.admins.push(newAdminId);
  saveAdmins(adminData);
  bot.sendMessage(chatId, `✅ Admin berhasil ditambahkan: \`${newAdminId}\``, { parse_mode: "Markdown" });
});

// Hapus Admin
bot.onText(/\/delpt(?:\s+(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const adminToRemove = parseInt(match[1]);

  if (!isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner yang bisa menghapus admin!");
  if (!match[1]) return bot.sendMessage(chatId, "❗ Format salah!\n\nGunakan:\n`/delpt <USER_ID>`", { parse_mode: "Markdown" });
  if (isNaN(adminToRemove)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const adminData = loadAdmins();
  if (!adminData.admins.includes(adminToRemove)) return bot.sendMessage(chatId, "⚠️ Admin tidak ditemukan!");

  adminData.admins = adminData.admins.filter((id) => id !== adminToRemove);
  saveAdmins(adminData);
  bot.sendMessage(chatId, `✅ Admin berhasil dihapus: \`${adminToRemove}\``, { parse_mode: "Markdown" });
});

// Tambah Reseller
bot.onText(/\/addreseller(?:\s+(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newResellerId = parseInt(match[1]);

  if (!isAdmin(userId) && !isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner dan admin yang bisa menambah reseller!");
  if (!match[1]) return bot.sendMessage(chatId, "❗ Format salah!\n\nGunakan:\n`/addreseller <USER_ID>`", { parse_mode: "Markdown" });
  if (isNaN(newResellerId)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const resellerData = loadResellers();
  if (resellerData.resellers.includes(newResellerId)) return bot.sendMessage(chatId, "⚠️ Reseller sudah ada!");

  resellerData.resellers.push(newResellerId);
  saveResellers(resellerData);
  bot.sendMessage(chatId, `✅ Reseller berhasil ditambahkan: \`${newResellerId}\``, { parse_mode: "Markdown" });
});

// Hapus Reseller
bot.onText(/\/delreseller(?:\s+(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const resellerToRemove = parseInt(match[1]);

  if (!isAdmin(userId) && !isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner dan admin yang bisa menghapus reseller!");
  if (!match[1]) return bot.sendMessage(chatId, "❗ Format salah!\n\nGunakan:\n`/delreseller <USER_ID>`", { parse_mode: "Markdown" });
  if (isNaN(resellerToRemove)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const resellerData = loadResellers();
  if (!resellerData.resellers.includes(resellerToRemove)) return bot.sendMessage(chatId, "⚠️ Reseller tidak ditemukan!");

  resellerData.resellers = resellerData.resellers.filter((id) => id !== resellerToRemove);
  saveResellers(resellerData);
  bot.sendMessage(chatId, `✅ Reseller berhasil dihapus: \`${resellerToRemove}\``, { parse_mode: "Markdown" });
});

// List Reseller
bot.onText(/\/listreseller/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isAdmin(userId) && !isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");
  }

  const resellers = loadResellers().resellers || [];
  if (resellers.length === 0) {
    return bot.sendMessage(chatId, "🚫 Tidak ada reseller yang terdaftar.");
  }

  const list = resellers.map((r, i) => `${i + 1}. \`${r}\``).join("\n");
  bot.sendMessage(chatId, `👥 *Daftar Reseller:*\n\n${list}`, { parse_mode: "Markdown" });
});




// Tambah Token
bot.onText(/\/addtoken(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newToken = match[1]?.trim();

  if (!hasAccess(userId)) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");
  }

  if (!newToken) {
    return bot.sendMessage(chatId, "❗ Format salah!\n\nGunakan:\n`/addtoken <TOKEN>`", {
      parse_mode: "Markdown"
    });
  }

  const tokens = await fetchTokens();
  if (tokens.includes(newToken)) {
    return bot.sendMessage(chatId, "⚠️ Token sudah ada!");
  }

  tokens.push(newToken);
  const success = await updateTokens(tokens);

  if (success) {
    bot.sendMessage(chatId, `✅ Token berhasil ditambahkan!`);
  } else {
    bot.sendMessage(chatId, "❌ Gagal menambahkan token!");
  }
});

// Hapus Token
bot.onText(/\/deltoken(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const tokenToRemove = match[1]?.trim();

  if (!hasAccess(userId)) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");
  }

  if (!tokenToRemove) {
    return bot.sendMessage(chatId, "❗ Format salah!\n\nGunakan:\n`/deltoken <TOKEN>`", {
      parse_mode: "Markdown"
    });
  }

  const tokens = await fetchTokens();
  if (!tokens.includes(tokenToRemove)) {
    return bot.sendMessage(chatId, "⚠️ Token tidak ditemukan!");
  }

  const updatedTokens = tokens.filter((token) => token !== tokenToRemove);
  const success = await updateTokens(updatedTokens);

  if (success) {
    bot.sendMessage(chatId, `✅ Token berhasil dihapus!`);
  } else {
    bot.sendMessage(chatId, "❌ Gagal menghapus token!");
  }
});

// List Token
bot.onText(/\/listtoken/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!hasAccess(userId)) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");
  }

  const tokens = await fetchTokens();
  if (tokens.length === 0) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada token tersimpan.");
  }

  const tokenList = tokens.join("\n");
  bot.sendMessage(chatId, `📜 **Daftar Token:**\n\`\`\`${tokenList}\`\`\``, {
    parse_mode: "Markdown"
  });
});


// ---------- LANJUTKAN DENGAN FUNGSI ADMIN DAN OWNER LAINNYA ----------
  function startBot() {
  console.clear();
  console.log(chalk.red(`\n
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⣿⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⢹⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⡄⠀⠀⠀⣤⣦⣤⣄⡀⢸⠸⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡆⠀⠉⠁⠀⠀⠀⢷⡙⠀⠈⠉⢻⠀⡇⠀⠀⠀⠀⠀⢀⣤⠶⠛⠛⠓⠊⡗⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠒⣿⠚⠀⢠⡄⠀⠀⠈⢷⢀⠀⠀⡏⡇⢯⠁⢦⣀⣴⠞⠋⠀⣠⡄⠀⠀⢸⠛⠀⠀⠀⣤⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠚⠀⠀⠀⠙⢦⣄⠀⠈⠳⡀⢰⢷⣷⣸⠦⠟⠛⠢⣠⣠⡶⠋⠀⠀⣠⠏⠀⠀⠀⠀⠉⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢫⣓⢦⡀⢙⡮⣾⣿⣇⢧⠀⣀⡴⣺⠿⣄⠀⡀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠱⣲⣭⣉⣜⠏⠀⠹⢊⣍⣽⣷⠏⠀⠀⣲⣿⣅⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⠄⣴⣷⠋⠀⠀⠀⠀⠀⠀⠈⠹⣞⠦⠀⠐⣃⡟⠠⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠠⠤⠤⠤⠶⠶⠶⠶⣖⣚⣒⣋⣉⡩⠭⠴⢶⣶⣿⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⢙⣿⣷⡶⠶⠭⣍⣙⣜⣒⣓⣒⠶⠶⠶⠶⠤⠤⠤⠄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠙⠚⠂⠮⣷⡀⡀⠀⠀⠀⠀⠀⢀⣤⣿⠷⢔⠚⠋⠉⠉⠁⠈⢣⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠃⠀⠀⣰⣻⣿⣿⢃⣄⠀⣰⣼⣟⠿⡼⣄⠈⠒⢄⡀⠀⠀⠀⠀⢳⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠟⠁⠀⠀⡴⣱⠟⠋⠉⠿⢿⣻⡟⠟⠏⠙⠦⣜⣆⠀⠀⠈⠓⠦⢄⣤⣾⠇⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⡟⠀⠀⢀⡾⠛⠁⠀⠀⡠⠾⡞⣿⢰⠀⠀⠀⠀⠈⠛⢧⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⠀⠀⠘⠏⠀⠀⣠⠔⠋⠀⠈⡇⠃⡾⠆⠀⠀⠀⠀⠀⠀⠙⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⣿⣌⠂⠀⣀⡠⠔⠋⠀⠀⠀⠀⠀⢱⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⢸⢠⢷⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⢸⡉⠀⠀⠀⠶⡷⠗⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀          ⠸⠷⠀⠀
                                    ⠟⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

`));
console.log(chalk.bold.blue(`
═════════════════════════
 developer : KBN STORE
 Bot Add Token
═════════════════════════
`));
console.log("✅ Bot berjalan...");
};
startBot()