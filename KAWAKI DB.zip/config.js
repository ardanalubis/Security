module.exports = {
  BOT_TOKEN: "8349833307:AAFf9hFqP0vlqytGlRps-JZ_HyUjrQmwrpQ",
    GITHUB_REPO: "Security/Database",
    GITHUB_FILE_PATH: "token.json",
    GITHUB_PAT: "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",    };